<?php
$dalTabletitlestwo1_uggroups = array();
$dalTabletitlestwo1_uggroups["GroupID"] = array("type"=>3,"varname"=>"GroupID");
$dalTabletitlestwo1_uggroups["Label"] = array("type"=>200,"varname"=>"Label");
	$dalTabletitlestwo1_uggroups["GroupID"]["key"]=true;
$dal_info["titlestwo1_uggroups"]=&$dalTabletitlestwo1_uggroups;

?>