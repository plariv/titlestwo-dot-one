<?php
$dalTablesearch5 = array();
$dalTablesearch5["idttl_actions"] = array("type"=>3,"varname"=>"idttl_actions");
$dalTablesearch5["FileNumber"] = array("type"=>200,"varname"=>"FileNumber");
$dalTablesearch5["NameOfSeller"] = array("type"=>200,"varname"=>"NameOfSeller");
$dalTablesearch5["NameOfBuyer"] = array("type"=>200,"varname"=>"NameOfBuyer");
$dalTablesearch5["NameOfBroker"] = array("type"=>200,"varname"=>"NameOfBroker");
$dalTablesearch5["BrokerCo"] = array("type"=>200,"varname"=>"BrokerCo");
$dalTablesearch5["PropAddress"] = array("type"=>200,"varname"=>"PropAddress");
$dalTablesearch5["City"] = array("type"=>200,"varname"=>"City");
$dalTablesearch5["MortgageBy"] = array("type"=>200,"varname"=>"MortgageBy");
$dalTablesearch5["Client A"] = array("type"=>200,"varname"=>"Client_A");
$dalTablesearch5["Client B"] = array("type"=>200,"varname"=>"Client_B");
$dalTablesearch5["Tenant"] = array("type"=>200,"varname"=>"Tenant");
$dalTablesearch5["Matter"] = array("type"=>200,"varname"=>"Matter");
$dal_info["search5"]=&$dalTablesearch5;

?>