<?php
$dalTableproperties = array();
$dalTableproperties["idproperties"] = array("type"=>3,"varname"=>"idproperties");
$dalTableproperties["propaddr1"] = array("type"=>200,"varname"=>"propaddr1");
$dalTableproperties["propaddr2"] = array("type"=>200,"varname"=>"propaddr2");
$dalTableproperties["propcity"] = array("type"=>200,"varname"=>"propcity");
$dalTableproperties["propstate"] = array("type"=>200,"varname"=>"propstate");
$dalTableproperties["proppostal"] = array("type"=>200,"varname"=>"proppostal");
$dalTableproperties["propplatte"] = array("type"=>200,"varname"=>"propplatte");
$dalTableproperties["proplot"] = array("type"=>200,"varname"=>"proplot");
$dalTableproperties["proplong"] = array("type"=>13,"varname"=>"proplong");
$dalTableproperties["proplat"] = array("type"=>13,"varname"=>"proplat");
	$dalTableproperties["idproperties"]["key"]=true;
$dal_info["properties"]=&$dalTableproperties;

?>