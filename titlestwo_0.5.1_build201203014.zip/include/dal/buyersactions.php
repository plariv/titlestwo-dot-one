<?php
$dalTablebuyersactions = array();
$dalTablebuyersactions["idbuyers"] = array("type"=>3,"varname"=>"idbuyers");
$dalTablebuyersactions["ttl_actions_idttl_actions"] = array("type"=>3,"varname"=>"ttl_actions_idttl_actions");
$dalTablebuyersactions["parties_idparties"] = array("type"=>3,"varname"=>"parties_idparties");
$dalTablebuyersactions["idparties"] = array("type"=>3,"varname"=>"idparties");
$dalTablebuyersactions["name"] = array("type"=>200,"varname"=>"name");
$dal_info["buyersactions"]=&$dalTablebuyersactions;

?>