<?php
$dalTablettl_actions = array();
$dalTablettl_actions["idttl_actions"] = array("type"=>3,"varname"=>"idttl_actions");
$dalTablettl_actions["ttlnumb"] = array("type"=>200,"varname"=>"ttlnumb");
$dalTablettl_actions["whencreated"] = array("type"=>7,"varname"=>"whencreated");
$dalTablettl_actions["examiner"] = array("type"=>200,"varname"=>"examiner");
$dalTablettl_actions["filecabinet"] = array("type"=>200,"varname"=>"filecabinet");
$dalTablettl_actions["properties_idproperties"] = array("type"=>3,"varname"=>"properties_idproperties");
$dalTablettl_actions["titleconame"] = array("type"=>200,"varname"=>"titleconame");
$dalTablettl_actions["titlepolicy"] = array("type"=>200,"varname"=>"titlepolicy");
$dalTablettl_actions["titlephone"] = array("type"=>200,"varname"=>"titlephone");
$dalTablettl_actions["titleremit"] = array("type"=>5,"varname"=>"titleremit");
$dalTablettl_actions["titleatty"] = array("type"=>200,"varname"=>"titleatty");
$dalTablettl_actions["titlerefatty"] = array("type"=>200,"varname"=>"titlerefatty");
$dalTablettl_actions["titlerecv"] = array("type"=>7,"varname"=>"titlerecv");
$dalTablettl_actions["closesched_date"] = array("type"=>7,"varname"=>"closesched_date");
$dalTablettl_actions["closesched_time"] = array("type"=>200,"varname"=>"closesched_time");
$dalTablettl_actions["sellprice"] = array("type"=>5,"varname"=>"sellprice");
$dalTablettl_actions["deposit"] = array("type"=>5,"varname"=>"deposit");
$dalTablettl_actions["loanamt"] = array("type"=>5,"varname"=>"loanamt");
$dalTablettl_actions["refi_purch"] = array("type"=>200,"varname"=>"refi_purch");
$dalTablettl_actions["res_comm"] = array("type"=>200,"varname"=>"res_comm");
$dalTablettl_actions["file_status"] = array("type"=>200,"varname"=>"file_status");
$dalTablettl_actions["file_archlocation"] = array("type"=>200,"varname"=>"file_archlocation");
$dalTablettl_actions["client1"] = array("type"=>200,"varname"=>"client1");
$dalTablettl_actions["client2"] = array("type"=>200,"varname"=>"client2");
$dalTablettl_actions["claddr1"] = array("type"=>200,"varname"=>"claddr1");
$dalTablettl_actions["claddr2"] = array("type"=>200,"varname"=>"claddr2");
$dalTablettl_actions["clphone1"] = array("type"=>200,"varname"=>"clphone1");
$dalTablettl_actions["clphone2"] = array("type"=>200,"varname"=>"clphone2");
$dalTablettl_actions["tenant"] = array("type"=>200,"varname"=>"tenant");
$dalTablettl_actions["matter"] = array("type"=>200,"varname"=>"matter");
$dalTablettl_actions["staffatty"] = array("type"=>200,"varname"=>"staffatty");
	$dalTablettl_actions["idttl_actions"]["key"]=true;
	$dalTablettl_actions["properties_idproperties"]["key"]=true;
$dal_info["ttl_actions"]=&$dalTablettl_actions;

?>