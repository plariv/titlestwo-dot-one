<?php
$dalTabletitlestwo1_ugmembers = array();
$dalTabletitlestwo1_ugmembers["UserName"] = array("type"=>200,"varname"=>"UserName");
$dalTabletitlestwo1_ugmembers["GroupID"] = array("type"=>3,"varname"=>"GroupID");
$dal_info["titlestwo1_ugmembers"]=&$dalTabletitlestwo1_ugmembers;

?>