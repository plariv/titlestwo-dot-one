<?php
$dalTabletitlestwo1_ugrights = array();
$dalTabletitlestwo1_ugrights["TableName"] = array("type"=>200,"varname"=>"TableName");
$dalTabletitlestwo1_ugrights["GroupID"] = array("type"=>3,"varname"=>"GroupID");
$dalTabletitlestwo1_ugrights["AccessMask"] = array("type"=>200,"varname"=>"AccessMask");
$dal_info["titlestwo1_ugrights"]=&$dalTabletitlestwo1_ugrights;

?>