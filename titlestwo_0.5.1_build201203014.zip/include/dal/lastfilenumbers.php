<?php
$dalTablelastfilenumbers = array();
$dalTablelastfilenumbers["fileyear"] = array("type"=>200,"varname"=>"fileyear");
$dalTablelastfilenumbers["lastfile"] = array("type"=>200,"varname"=>"lastfile");
	$dalTablelastfilenumbers["fileyear"]["key"]=true;
$dal_info["lastfilenumbers"]=&$dalTablelastfilenumbers;

?>