<?php
$dalTablettl_recordings = array();
$dalTablettl_recordings["idttl_recordings"] = array("type"=>3,"varname"=>"idttl_recordings");
$dalTablettl_recordings["mort"] = array("type"=>200,"varname"=>"mort");
$dalTablettl_recordings["disrec"] = array("type"=>200,"varname"=>"disrec");
$dalTablettl_recordings["whenrecorded"] = array("type"=>135,"varname"=>"whenrecorded");
$dalTablettl_recordings["book"] = array("type"=>200,"varname"=>"book");
$dalTablettl_recordings["page"] = array("type"=>200,"varname"=>"page");
$dalTablettl_recordings["account"] = array("type"=>200,"varname"=>"account");
$dalTablettl_recordings["ttl_actions_idttl_actions"] = array("type"=>3,"varname"=>"ttl_actions_idttl_actions");
	$dalTablettl_recordings["idttl_recordings"]["key"]=true;
	$dalTablettl_recordings["ttl_actions_idttl_actions"]["key"]=true;
$dal_info["ttl_recordings"]=&$dalTablettl_recordings;

?>