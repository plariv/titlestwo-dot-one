<?php
$dalTablesellers = array();
$dalTablesellers["idsellers"] = array("type"=>3,"varname"=>"idsellers");
$dalTablesellers["ttl_actions_idttl_actions"] = array("type"=>3,"varname"=>"ttl_actions_idttl_actions");
$dalTablesellers["parties_idparties"] = array("type"=>3,"varname"=>"parties_idparties");
	$dalTablesellers["idsellers"]["key"]=true;
$dal_info["sellers"]=&$dalTablesellers;

?>