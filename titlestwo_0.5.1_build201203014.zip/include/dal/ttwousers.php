<?php
$dalTablettwousers = array();
$dalTablettwousers["id"] = array("type"=>3,"varname"=>"id");
$dalTablettwousers["username"] = array("type"=>200,"varname"=>"username");
$dalTablettwousers["password"] = array("type"=>200,"varname"=>"password");
$dalTablettwousers["active"] = array("type"=>16,"varname"=>"active");
$dalTablettwousers["firstname"] = array("type"=>200,"varname"=>"firstname");
$dalTablettwousers["lastname"] = array("type"=>200,"varname"=>"lastname");
$dalTablettwousers["datecreated"] = array("type"=>135,"varname"=>"datecreated");
$dalTablettwousers["groupmember"] = array("type"=>200,"varname"=>"groupmember");
$dalTablettwousers["emailaddr"] = array("type"=>200,"varname"=>"emailaddr");
	$dalTablettwousers["id"]["key"]=true;
$dal_info["ttwousers"]=&$dalTablettwousers;

?>