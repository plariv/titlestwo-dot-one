<?php
$dalTablesellersactions = array();
$dalTablesellersactions["idsellers"] = array("type"=>3,"varname"=>"idsellers");
$dalTablesellersactions["ttl_actions_idttl_actions"] = array("type"=>3,"varname"=>"ttl_actions_idttl_actions");
$dalTablesellersactions["parties_idparties"] = array("type"=>3,"varname"=>"parties_idparties");
$dalTablesellersactions["idparties"] = array("type"=>3,"varname"=>"idparties");
$dalTablesellersactions["name"] = array("type"=>200,"varname"=>"name");
$dal_info["sellersactions"]=&$dalTablesellersactions;

?>