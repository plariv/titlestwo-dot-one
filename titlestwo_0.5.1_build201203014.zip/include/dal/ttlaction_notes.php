<?php
$dalTablettlaction_notes = array();
$dalTablettlaction_notes["idnotes"] = array("type"=>3,"varname"=>"idnotes");
$dalTablettlaction_notes["ttlactions_idttlactions"] = array("type"=>3,"varname"=>"ttlactions_idttlactions");
$dalTablettlaction_notes["created"] = array("type"=>7,"varname"=>"created");
$dalTablettlaction_notes["note_content"] = array("type"=>201,"varname"=>"note_content");
	$dalTablettlaction_notes["idnotes"]["key"]=true;
$dal_info["ttlaction_notes"]=&$dalTablettlaction_notes;

?>