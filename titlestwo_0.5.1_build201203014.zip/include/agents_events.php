<?php 
class eventclass_agents  extends eventsBase
{ 
	function eventclass_agents()
	{
	// fill list of events

//	onscreen events
		$this->events["agents_snippet"] = true;


	}
// Captchas functions	

//	handlers
//	onscreen events
function agents_snippet(&$params)
{
// Put your code here.
echo "Address book for brokers and attorneys";

;
}

} 
?>
