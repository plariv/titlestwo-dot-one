
var custom_label_map={"English":{}};function GetCustomLabel(name)
{return custom_label_map[current_language][name];}